import { useEffect, useRef, useState } from "react";

// ─── timing — slow, watchable ─────────────────────────────────────────────────
// Total loop: 34 seconds — Stage 5 lingers so audience reads the answer
const LOOP = 34000;

const WINDOWS = [
  [400,  5000],   // 0: You ask        (~4.6s)
  [5200, 9500],   // 1: Intent         (~4.3s)
  [9700, 14200],  // 2: RAG ChromaDB   (~4.5s)
  [14400,18800],  // 3: Reranker       (~4.4s)
  [19000,33500],  // 4: Claude answers (~14.5s — streams in 6s, holds 8s)
] as const;

const C = {
  1: { hex: "#1E90FF", rgb: "30,144,255" },
  2: { hex: "#F59E0B", rgb: "245,158,11" },
  3: { hex: "#10B981", rgb: "16,185,129" },
  4: { hex: "#8B5CF6", rgb: "139,92,246" },
  5: { hex: "#EF4444", rgb: "239,68,68" },
} as const;

function useLoopMs() {
  const [ms, setMs] = useState(0);
  const start = useRef(performance.now());
  useEffect(() => {
    let id: number;
    const tick = (now: number) => {
      setMs((now - start.current) % LOOP);
      id = requestAnimationFrame(tick);
    };
    id = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(id);
  }, []);
  return ms;
}

function inW(ms: number, i: number) {
  return ms >= WINDOWS[i][0] && ms <= WINDOWS[i][1];
}
function pct(ms: number, from: number, dur: number) {
  return Math.min(1, Math.max(0, (ms - from) / dur));
}

// ─── Jumping dots (system thinking) ──────────────────────────────────────────
function ThinkingDots({ color }: { color: string }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "flex-end", gap: 5, height: 18 }}>
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          style={{
            display: "inline-block",
            width: 9,
            height: 9,
            borderRadius: "50%",
            background: color,
            animation: `jumpDot 1.1s ${i * 0.18}s ease-in-out infinite`,
            boxShadow: `0 0 6px ${color}88`,
          }}
        />
      ))}
    </span>
  );
}

// ─── Neo character ─────────────────────────────────────────────────────────────
// State is stable: confused until stage 5, happy after stage 5, no re-pops
function Neo({ activeIdx }: { activeIdx: number }) {
  const happy = activeIdx === 4;
  // Neo's state is set ONCE when stage changes — held stable 2-4
  const emoji = happy ? "😄" : activeIdx === -1 ? "😕" : "🤔";
  const label = happy ? "Neo is happy!" : activeIdx === -1 ? "Neo is confused" : "Neo is thinking…";
  const bubble = happy
    ? "Finally! Now I know exactly which queries to fix."
    : activeIdx === -1
    ? '"I have no idea which\nqueries are burning\nmy BigQuery budget!"'
    : '"Hmm, let me see\nwhat the system\nfinds for me…"';

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 7, flexShrink: 0, width: 90 }}>
      {/* speech bubble — stable, no re-animation 2-4 */}
      <div
        style={{
          background: happy ? "#F0FDF4" : "#F8FAFC",
          border: `1.5px solid ${happy ? "#86EFAC" : "#E2E8F0"}`,
          borderRadius: 9,
          padding: "7px 8px",
          fontSize: 9.5,
          color: happy ? "#166534" : "#475569",
          lineHeight: 1.45,
          textAlign: "center",
          position: "relative",
          width: "100%",
          fontWeight: 500,
          whiteSpace: "pre-line",
        }}
      >
        {bubble}
        <div style={{
          position: "absolute", bottom: -7, left: "50%", transform: "translateX(-50%)",
          width: 0, height: 0,
          borderLeft: "6px solid transparent", borderRight: "6px solid transparent",
          borderTop: `7px solid ${happy ? "#86EFAC" : "#E2E8F0"}`,
        }} />
      </div>

      {/* avatar */}
      <div
        style={{
          width: 52,
          height: 52,
          borderRadius: "50%",
          background: happy
            ? "linear-gradient(135deg,#DCFCE7,#BBF7D0)"
            : activeIdx >= 1 && activeIdx <= 3
            ? "linear-gradient(135deg,#FEF9C3,#FDE68A)"
            : "linear-gradient(135deg,#F1F5F9,#E2E8F0)",
          border: `2.5px solid ${happy ? "#22C55E" : activeIdx >= 1 ? "#F59E0B" : "#CBD5E1"}`,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 24,
          boxShadow: happy ? "0 0 18px #22C55E44" : "none",
          transition: "all 0.7s ease",
          animation: happy ? "bouncePop 0.55s cubic-bezier(.17,.67,.83,.67)" : activeIdx >= 1 && activeIdx <= 3 ? "gentleBob 2.5s ease-in-out infinite" : "none",
          flexShrink: 0,
        }}
      >
        {emoji}
      </div>

      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: "#E6EDF3" }}>Neo</div>
        <div style={{ fontSize: 9, color: happy ? "#22C55E" : "#8B949E" }}>{label}</div>
      </div>
    </div>
  );
}

// ─── Arrow connector ──────────────────────────────────────────────────────────
function Arrow({ n, on }: { n: 1 | 2 | 3 | 4; on: boolean }) {
  const col = C[n];
  return (
    <div style={{ width: 42, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
      <svg width="42" height="20" viewBox="0 0 42 20" style={{ overflow: "visible" }}>
        <defs>
          <marker id={`ah-${n}`} markerWidth="7" markerHeight="7" refX="5" refY="3.5" orient="auto">
            <path d="M0,0 L7,3.5 L0,7 Z" fill={on ? col.hex : "#2A3140"} style={{ transition: "fill 0.4s" }} />
          </marker>
        </defs>
        <line
          x1="0" y1="10" x2="34" y2="10"
          stroke={on ? col.hex : "#2A3140"}
          strokeWidth={on ? 2.5 : 1.5}
          strokeDasharray="7 4"
          markerEnd={`url(#ah-${n})`}
          style={{ transition: "stroke 0.4s, stroke-width 0.4s", animation: on ? "dashMove 0.5s linear infinite" : "none" }}
        />
      </svg>
      {on && (
        <span style={{
          position: "absolute", top: "50%", left: 0, width: 10, height: 10,
          borderRadius: "50%", background: col.hex, transform: "translateY(-50%)",
          boxShadow: `0 0 12px 4px ${col.hex}`,
          animation: "dotTravel 0.9s ease-in-out infinite",
          pointerEvents: "none",
        }} />
      )}
    </div>
  );
}

// ─── Progress bar ─────────────────────────────────────────────────────────────
function ProgressBar({ activeIdx }: { activeIdx: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 3, marginBottom: 10, flexShrink: 0 }}>
      {[C[1], C[2], C[3], C[4], C[5]].map((col, i) => {
        const done = i < activeIdx;
        const active = i === activeIdx;
        return (
          <div key={i} style={{ flex: 1, height: 3, borderRadius: 2,
            background: done ? col.hex : active ? `rgba(${col.rgb},0.55)` : "#21262D",
            boxShadow: active ? `0 0 10px ${col.hex}` : "none",
            transition: "all 0.6s ease",
            animation: active ? "barPulse 1.8s ease-in-out infinite" : "none",
          }} />
        );
      })}
    </div>
  );
}

// ─── Stage 1: Streamlit chat (white bg) ───────────────────────────────────────
const QUERY = "What are the costliest queries in the last 7 days?";

function Stage1({ ms }: { ms: number }) {
  const on = inW(ms, 0);
  const p = pct(ms, 600, 3800);
  const chars = Math.floor(p * QUERY.length);
  const shown = QUERY.slice(0, chars);
  const typing = on && p < 1;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 7, height: "100%" }}>
      <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
        {["project: rea-gcp-dp-dev", "last_7_days", "palak@rea"].map((f) => (
          <span key={f} style={{ padding: "2px 7px", borderRadius: 4, fontSize: 9, fontFamily: "'JetBrains Mono',monospace", background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}>{f}</span>
        ))}
      </div>

      <div style={{ flex: 1, borderRadius: 10, overflow: "hidden", display: "flex", flexDirection: "column", background: "#FFFFFF", border: "1.5px solid #E2E8F0", boxShadow: on ? "0 4px 24px rgba(30,144,255,0.14)" : "0 2px 8px rgba(0,0,0,0.07)", transition: "box-shadow 0.5s", minHeight: 0 }}>
        {/* titlebar */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "7px 10px", background: "#F8FAFC", borderBottom: "1px solid #E2E8F0", flexShrink: 0 }}>
          <span style={{ width: 9, height: 9, borderRadius: "50%", background: "#FF5F57" }} />
          <span style={{ width: 9, height: 9, borderRadius: "50%", background: "#FEBC2E" }} />
          <span style={{ width: 9, height: 9, borderRadius: "50%", background: "#28C840" }} />
          <span style={{ marginLeft: 8, fontSize: 10, fontFamily: "'JetBrains Mono',monospace", color: "#64748B" }}>🗂️ data-assistant</span>
        </div>

        <div style={{ flex: 1, padding: "10px", display: "flex", flexDirection: "column", justifyContent: "flex-end", gap: 8, overflow: "hidden" }}>
          {/* ghost history */}
          <div style={{ display: "flex", gap: 7, alignItems: "flex-start", opacity: 0.4 }}>
            <div style={{ width: 22, height: 22, borderRadius: "50%", background: "#EFF6FF", border: "1px solid #BFDBFE", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: "#3B82F6", flexShrink: 0 }}>N</div>
            <div style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", borderRadius: "4px 12px 12px 12px", padding: "6px 10px", fontSize: 11, color: "#475569" }}>Show me yesterday&#39;s slot usage</div>
          </div>
          <div style={{ display: "flex", gap: 7, justifyContent: "flex-end", opacity: 0.4 }}>
            <div style={{ background: "#F0FDF4", border: "1px solid #BBF7D0", borderRadius: "12px 4px 12px 12px", padding: "6px 10px", fontSize: 11, color: "#166534" }}>Total: 42,800 slot-ms across 17 jobs</div>
          </div>

          {/* live message */}
          <div style={{ display: "flex", gap: 7, alignItems: "flex-start" }}>
            <div style={{ width: 22, height: 22, borderRadius: "50%", background: "#EFF6FF", border: `1.5px solid ${C[1].hex}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: C[1].hex, flexShrink: 0, boxShadow: on ? `0 0 8px rgba(${C[1].rgb},0.4)` : "none", transition: "box-shadow 0.3s" }}>N</div>
            <div style={{ flex: 1, background: "#EFF6FF", border: `1.5px solid ${C[1].hex}`, borderRadius: "4px 12px 12px 12px", padding: "7px 10px", minHeight: 32, fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "#1E3A5F", lineHeight: 1.55 }}>
              {shown}
              {typing && <span style={{ display: "inline-block", width: 2, height: 13, background: C[1].hex, marginLeft: 2, verticalAlign: "middle", animation: "blink 0.65s step-end infinite" }} />}
            </div>
          </div>
        </div>

        <div style={{ display: "flex", gap: 6, padding: "7px 10px", borderTop: "1px solid #E2E8F0", flexShrink: 0, background: "#F8FAFC" }}>
          <div style={{ flex: 1, borderRadius: 6, padding: "4px 8px", fontSize: 10, fontFamily: "'JetBrains Mono',monospace", background: "#FFF", border: "1px solid #E2E8F0", color: "#CBD5E1" }}>Ask about BigQuery costs, assets…</div>
          <div style={{ padding: "4px 10px", borderRadius: 6, background: C[1].hex, color: "#FFF", fontSize: 10, fontWeight: 600, cursor: "pointer" }}>Send</div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 5 }}>
        {["Show slot quotas", "Top scanned tables", "Cost by team"].map((q) => (
          <span key={q} style={{ flex: 1, padding: "3px 6px", borderRadius: 5, fontSize: 9, fontFamily: "'JetBrains Mono',monospace", background: "#1C2128", color: "#8B949E", border: "1px solid #30363D", textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{q}</span>
        ))}
      </div>
    </div>
  );
}

// ─── Stage 2: Intent detection — bucket cursor ────────────────────────────────
// 3 intent buckets, each with keywords. A visible cursor sweeps between them,
// pauses, then locks onto "Queries Cost".
//
// Timeline (relative to WINDOWS[1][0] = 5200):
//   0–600ms   : buckets appear (stagger)
//   600–1600ms: cursor sits on 🔍 Asset Discovery
//   1600–2600ms: cursor moves to ⚙️ Optimisation
//   2600–3600ms: cursor moves to 💰 Queries Cost  ← selected
//   3600ms+   : Cost locked, others dimmed

const INTENT_BUCKETS = [
  {
    id: "cost",
    emoji: "💰",
    label: "Queries Cost",
    color: C[2],
    keywords: ["costli*", "expensive", "billing", "spend", "budget"],
    match: true,
  },
  {
    id: "asset",
    emoji: "🔍",
    label: "Asset Discovery",
    color: C[1],
    keywords: ["table", "schema", "column", "dataset", "catalog"],
    match: false,
  },
  {
    id: "opt",
    emoji: "⚙️",
    label: "Optimisation",
    color: C[4],
    keywords: ["reduce", "partition", "cluster", "improve", "slow"],
    match: false,
  },
] as const;

// cursor visits: asset (idx 1) → optimisation (idx 2) → cost (idx 0)
const CURSOR_SEQUENCE = [1, 2, 0] as const;

function IntentBucket({
  bucket,
  cursorOn,
  selected,
  dimmed,
  visible,
}: {
  bucket: typeof INTENT_BUCKETS[number];
  cursorOn: boolean;
  selected: boolean;
  dimmed: boolean;
  visible: boolean;
}) {
  const col = bucket.color;
  return (
    <div
      style={{
        flex: 1,
        borderRadius: 10,
        border: selected
          ? `2px solid ${col.hex}`
          : cursorOn
          ? `2px solid ${col.hex}88`
          : "1px solid #21262D",
        background: selected
          ? `rgba(${col.rgb},0.12)`
          : cursorOn
          ? `rgba(${col.rgb},0.06)`
          : "#111820",
        opacity: !visible ? 0 : dimmed ? 0.28 : 1,
        transform: visible ? "translateY(0) scale(1)" : "translateY(12px) scale(0.95)",
        transition: "all 0.45s cubic-bezier(.17,.67,.83,.67)",
        boxShadow: selected
          ? `0 0 22px rgba(${col.rgb},0.32)`
          : cursorOn
          ? `0 0 12px rgba(${col.rgb},0.18)`
          : "none",
        padding: "9px 10px",
        display: "flex",
        flexDirection: "column",
        gap: 6,
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* cursor blink bar at top */}
      {cursorOn && !selected && (
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            height: 3,
            background: col.hex,
            borderRadius: "10px 10px 0 0",
            animation: "barPulse 0.8s ease-in-out infinite",
          }}
        />
      )}

      {/* header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 16 }}>{bucket.emoji}</span>
          <span
            style={{
              fontSize: 11,
              fontWeight: 700,
              color: selected || cursorOn ? col.hex : "#8B949E",
              transition: "color 0.3s",
            }}
          >
            {bucket.label}
          </span>
        </div>
        {selected && (
          <span style={{ fontSize: 15, animation: "bouncePop 0.45s cubic-bezier(.17,.67,.83,.67)", flexShrink: 0 }}>
            ✅
          </span>
        )}
        {cursorOn && !selected && (
          <span
            style={{
              fontSize: 9,
              fontFamily: "'JetBrains Mono',monospace",
              color: col.hex,
              animation: "blink 0.7s step-end infinite",
              fontWeight: 700,
            }}
          >
            ▶ scanning
          </span>
        )}
        {dimmed && <span style={{ fontSize: 11, color: "#3D444D" }}>✕</span>}
      </div>

      {/* keywords */}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
        {bucket.keywords.map((kw) => (
          <span
            key={kw}
            style={{
              padding: "2px 6px",
              borderRadius: 4,
              fontSize: 9,
              fontFamily: "'JetBrains Mono',monospace",
              background: selected
                ? `rgba(${col.rgb},0.18)`
                : cursorOn
                ? `rgba(${col.rgb},0.1)`
                : "#1C2128",
              color: selected || cursorOn ? col.hex : "#3D444D",
              border: `1px solid ${selected || cursorOn ? `rgba(${col.rgb},0.35)` : "#30363D"}`,
              transition: "all 0.3s",
            }}
          >
            {kw}
          </span>
        ))}
      </div>
    </div>
  );
}

function Stage2({ ms }: { ms: number }) {
  const on = inW(ms, 1);
  const local = Math.max(0, ms - 5200);

  // which bucket index has the cursor right now
  // 600–1600 → CURSOR_SEQUENCE[0] = 1 (Asset)
  // 1600–2600 → CURSOR_SEQUENCE[1] = 2 (Optimisation)
  // 2600+    → CURSOR_SEQUENCE[2] = 0 (Cost)
  let cursorIdx = -1;
  if (on && local >= 400) {
    if (local < 1500) cursorIdx = CURSOR_SEQUENCE[0];
    else if (local < 2500) cursorIdx = CURSOR_SEQUENCE[1];
    else cursorIdx = CURSOR_SEQUENCE[2];
  }
  const selected = on && local >= 3400; // Cost locked in

  // stagger bucket appearance
  const bucketVis = [local > 200, local > 500, local > 800];

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, height: "100%" }}>
      {/* query preview */}
      <div
        style={{
          padding: "5px 9px",
          borderRadius: 6,
          background: "#080D13",
          border: "1px solid #21262D",
          fontSize: 10,
          fontFamily: "'JetBrains Mono',monospace",
          color: "#8B949E",
          flexShrink: 0,
        }}
      >
        <span style={{ color: "#3D444D" }}>› </span>
        <span style={{ color: "#C9D1D9" }}>"…the </span>
        <span style={{ color: C[2].hex, background: `rgba(${C[2].rgb},0.15)`, borderRadius: 3, padding: "0 3px" }}>
          costliest
        </span>
        <span style={{ color: "#C9D1D9" }}> queries in the last </span>
        <span style={{ color: "#58A6FF" }}>7 days</span>
        <span style={{ color: "#C9D1D9" }}>…"</span>
      </div>

      {/* label */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 9, color: "#8B949E", fontFamily: "'JetBrains Mono',monospace" }}>
          intent classifier · scanning buckets
        </span>
        {selected && (
          <span
            style={{
              fontSize: 9,
              fontFamily: "'JetBrains Mono',monospace",
              color: C[2].hex,
              padding: "1px 6px",
              borderRadius: 3,
              background: `rgba(${C[2].rgb},0.12)`,
              border: `1px solid rgba(${C[2].rgb},0.3)`,
              animation: "popIn 0.3s ease",
            }}
          >
            intent locked ✓
          </span>
        )}
      </div>

      {/* 3 side-by-side buckets */}
      <div style={{ flex: 1, display: "flex", gap: 8, minHeight: 0 }}>
        {INTENT_BUCKETS.map((bucket, i) => (
          <IntentBucket
            key={bucket.id}
            bucket={bucket}
            cursorOn={on && cursorIdx === i && !(selected && bucket.match)}
            selected={selected && bucket.match}
            dimmed={selected && !bucket.match}
            visible={on && bucketVis[i]}
          />
        ))}
      </div>

      {/* bottom status */}
      <div style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#8B949E", flexShrink: 0 }}>
        {!on
          ? ""
          : !selected && cursorIdx === 1
          ? "▶ checking Asset Discovery keywords…"
          : !selected && cursorIdx === 2
          ? "▶ checking Optimisation keywords…"
          : !selected && cursorIdx === 0
          ? "▶ checking Queries Cost keywords…"
          : selected
          ? `✓ matched intent: Queries Cost  (score: 0.94)`
          : "initialising…"}
      </div>
    </div>
  );
}

// ─── Stage 3: RAG (ChromaDB) ──────────────────────────────────────────────────
const COLS = [
  { name: "bq_query_history", chunks: 5, fill: 0.85, locked: false },
  { name: "bq_quota_metrics", chunks: 3, fill: 0.62, locked: false },
  { name: "bq_asset_catalog", chunks: 0, fill: 0, locked: true },
];
const THINK3 = ["Embedding query vector…", "Searching bq_query_history…", "Applying metadata filters…", "Computing cosine similarity…", "Ranking top chunks…"];

function Stage3({ ms }: { ms: number }) {
  const on = inW(ms, 2);
  const thinkEnd = 9700 + 1800;
  const thinking = on && ms < thinkEnd;
  const fillP = pct(ms, thinkEnd, 2000);
  const thinkStep = Math.min(THINK3.length - 1, Math.floor(pct(ms, 9700, 1800) * THINK3.length));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, height: "100%" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#8B949E" }}>vector store · cosine sim ≥ 0.72</span>
        {!thinking && on && <span style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: C[3].hex }}>{Math.round(fillP * 8)}/8 chunks</span>}
      </div>

      {/* thinking box */}
      <div style={{ borderRadius: 8, background: "#080D13", border: `1px solid ${thinking ? `rgba(${C[3].rgb},0.45)` : "#21262D"}`, padding: "10px 12px", flexShrink: 0, transition: "border-color 0.4s", minHeight: 68 }}>
        {thinking ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
              <ThinkingDots color={C[3].hex} />
              <span style={{ fontSize: 11, fontFamily: "'JetBrains Mono',monospace", color: C[3].hex, fontWeight: 600 }}>System is thinking…</span>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 3, marginTop: 2 }}>
              {THINK3.slice(0, thinkStep + 1).map((s, i) => (
                <div key={i} style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: i === thinkStep ? "#E6EDF3" : "#3D444D", paddingLeft: 6, animation: i === thinkStep ? "fadeSlideIn 0.3s ease" : "none" }}>
                  {i < thinkStep ? "✓ " : "› "}{s}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
            {["intent=cost", "window=7d", "project=rea-gcp-dp-dev", "user=palak@rea"].map((f) => (
              <span key={f} style={{ padding: "2px 7px", borderRadius: 4, fontSize: 9, fontFamily: "'JetBrains Mono',monospace", background: `rgba(${C[3].rgb},0.1)`, color: C[3].hex, border: `1px solid rgba(${C[3].rgb},0.3)` }}>{f}</span>
            ))}
          </div>
        )}
      </div>

      {/* collection bars */}
      <div style={{ flex: 1, borderRadius: 8, background: "#080D13", border: "1px solid #21262D", padding: "10px 12px", display: "flex", flexDirection: "column", justifyContent: "space-around", minHeight: 0 }}>
        {COLS.map((col, i) => {
          const lp = Math.max(0, Math.min(1, (fillP - i * 0.25) / 0.65));
          const w = col.locked ? 0 : lp * col.fill * 100;
          return (
            <div key={col.name} style={{ opacity: col.locked ? 0.28 : 1 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 5, fontFamily: "'JetBrains Mono',monospace", fontSize: 10 }}>
                <span style={{ color: col.locked ? "#3D444D" : "#C9D1D9" }}>{col.name}</span>
                {col.locked ? <span style={{ color: "#3D444D" }}>🔒 restricted</span> : <span style={{ color: C[3].hex, opacity: Math.min(1, lp * 2) }}>{col.chunks} chunks · filters ✓</span>}
              </div>
              <div style={{ height: 8, borderRadius: 4, background: "#1C2128", overflow: "hidden" }}>
                <div style={{ width: `${w}%`, height: "100%", borderRadius: 4, background: `linear-gradient(90deg, rgba(${C[3].rgb},0.6),${C[3].hex})`, transition: "width 1s cubic-bezier(.4,0,.2,1)", boxShadow: `0 0 12px rgba(${C[3].rgb},0.5)` }} />
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ display: "flex", gap: 6, alignItems: "center", flexShrink: 0 }}>
        <span style={{ fontSize: 9, color: "#8B949E", fontFamily: "'JetBrains Mono',monospace" }}>model:</span>
        <span style={{ padding: "2px 7px", borderRadius: 4, fontSize: 9, fontFamily: "'JetBrains Mono',monospace", background: `rgba(${C[3].rgb},0.1)`, color: C[3].hex, border: `1px solid rgba(${C[3].rgb},0.3)` }}>text-embedding-3-small</span>
      </div>
    </div>
  );
}

// ─── Stage 4: Reranker ────────────────────────────────────────────────────────
// Phase 1 (0–1400ms): ThinkingDots + step log
// Phase 2 (1400–2900ms): queries shuffle physically up/down in INIT order
// Phase 3 (2900ms+): items render in SORT order, stagger fade into ranked slots
// Phase 4 (3700ms+): top-3 highlighted, "passed to context" badge appears

const INIT_S = [
  { id: "s3", label: "events scan",   cost: "$2.10",       score: 0.81 },
  { id: "s5", label: "users join",    cost: "$1.80",       score: 0.77 },
  { id: "s1", label: "orders scan",   cost: "$4.20",       score: 0.94 },
  { id: "s7", label: "daily_agg",     cost: "$0.90",       score: 0.62 },
  { id: "s2", label: "quota summary", cost: "4,200 slot-ms", score: 0.89 },
  { id: "s6", label: "schema check",  cost: "$0.40",       score: 0.55 },
  { id: "s4", label: "audit_log",     cost: "$0.30",       score: 0.48 },
  { id: "s8", label: "dl_export",     cost: "$0.20",       score: 0.41 },
];
const SORT_S = [...INIT_S].sort((a, b) => b.score - a.score);
const THINK4 = [
  "Loading cross-encoder model…",
  "Scoring 8 candidate chunks…",
  "Comparing query–passage pairs…",
  "Normalising relevance scores…",
];

// Shuffle states — each is the visual order of item IDs top-to-bottom.
// Items slide between positions using absolute top, giving a real sort feel.
// init:    [s3, s5, s1, s7, s2, s6, s4, s8]
// step 1:  s1 rises to top  → [s1, s3, s5, s7, s2, s6, s4, s8]
// step 2:  s2 rises         → [s1, s2, s3, s5, s7, s6, s4, s8]  (≈ sorted)
// final:   identical to SORT_S, highlight top 3

const ITEM_H  = 30; // px per row (height + gap)
const N_ITEMS = INIT_S.length;

// ID → score lookup for quick access
const SCORE_MAP: Record<string, number> = {};
INIT_S.forEach((s) => { SCORE_MAP[s.id] = s.score; });

// Visual orderings that the animation steps through
const SHUFFLE_STAGES: string[][] = [
  ["s3","s5","s1","s7","s2","s6","s4","s8"], // 0 — initial unsorted
  ["s1","s5","s3","s7","s2","s6","s4","s8"], // 1 — s1 jumps to top
  ["s1","s2","s3","s5","s7","s6","s4","s8"], // 2 — s2 rises, s5 drops
  ["s1","s2","s3","s5","s7","s6","s4","s8"], // 3 — settle (= sorted)
];

function Stage4({ ms }: { ms: number }) {
  const on    = inW(ms, 3);
  const local = Math.max(0, ms - WINDOWS[3][0]);

  const THINK_DUR  = 1400; // ms
  const SHUF_DUR   = 2000; // ms — total shuffle window
  const SHUF_START = THINK_DUR;
  const SORT_START = THINK_DUR + SHUF_DUR; // 3400ms

  const thinking = on && local < THINK_DUR;
  const shuffling = on && local >= SHUF_START && local < SORT_START;
  const sorting   = on && local >= SORT_START;
  const expanded  = on && local >= SORT_START + 700;

  const thinkStep = Math.min(
    THINK4.length - 1,
    Math.floor(pct(ms, WINDOWS[3][0], THINK_DUR) * THINK4.length),
  );

  // Which shuffle stage are we in? Step every ~550ms
  const STEP_DUR = SHUF_DUR / (SHUFFLE_STAGES.length - 1);
  const shuffleStageIdx = Math.min(
    SHUFFLE_STAGES.length - 1,
    Math.floor((local - SHUF_START) / STEP_DUR),
  );
  const currentOrder = shuffling
    ? SHUFFLE_STAGES[shuffleStageIdx]
    : SHUFFLE_STAGES[SHUFFLE_STAGES.length - 1]; // stable final order

  // Build id → visual row index map for absolute positioning
  const posOf: Record<string, number> = {};
  currentOrder.forEach((id, i) => { posOf[id] = i; });

  // During final sort, resolve each id to its SORT_S rank
  const sortRankOf: Record<string, number> = {};
  SORT_S.forEach((s, i) => { sortRankOf[s.id] = i; });

  const listH = N_ITEMS * ITEM_H - 2; // total container height in px

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8, height: "100%" }}>
      {/* status line */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <span style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#8B949E" }}>
          {thinking  ? "cross-encoder · scoring…"
           : shuffling ? `cross-encoder · sorting… (step ${shuffleStageIdx + 1}/${SHUFFLE_STAGES.length - 1})`
           : "cross-encoder · sorted ↓"}
        </span>
        {sorting && (
          <span style={{ padding: "2px 7px", borderRadius: 4, fontSize: 9, fontFamily: "'JetBrains Mono',monospace", background: `rgba(${C[4].rgb},0.12)`, color: C[4].hex, border: `1px solid rgba(${C[4].rgb},0.35)` }}>
            top-3 selected
          </span>
        )}
      </div>

      {/* ── PHASE 1: thinking ── */}
      {thinking && (
        <div style={{ borderRadius: 8, background: "#080D13", border: `1px solid rgba(${C[4].rgb},0.45)`, padding: "10px 12px", flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 6 }}>
            <ThinkingDots color={C[4].hex} />
            <span style={{ fontSize: 11, fontFamily: "'JetBrains Mono',monospace", color: C[4].hex, fontWeight: 600 }}>Reranker is thinking…</span>
          </div>
          {THINK4.slice(0, thinkStep + 1).map((s, i) => (
            <div key={i} style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: i === thinkStep ? "#E6EDF3" : "#3D444D", paddingLeft: 6, marginTop: 3, animation: i === thinkStep ? "fadeSlideIn 0.3s ease" : "none" }}>
              {i < thinkStep ? "✓ " : "› "}{s}
            </div>
          ))}
        </div>
      )}

      {/* ── PHASE 1 placeholder so layout doesn't jump ── */}
      {thinking && (
        <div style={{ flex: 1, borderRadius: 8, background: "#080D13", border: "1px solid #1C2128", minHeight: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <span style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#3D444D" }}>8 candidate chunks queued…</span>
        </div>
      )}

      {/* ── PHASE 2 + 3: absolute-positioned rows that slide between slots ── */}
      {(shuffling || sorting) && (
        <div style={{ flex: 1, borderRadius: 8, background: "#080D13", border: "1px solid #21262D", padding: "5px 8px", position: "relative", overflow: "hidden", minHeight: listH }}>
          {INIT_S.map((s) => {
            // visual position during shuffle (drives the slide)
            const visualPos = shuffling ? posOf[s.id] : sortRankOf[s.id];
            const isTop  = sorting && sortRankOf[s.id] < 3;
            const isDim  = sorting && sortRankOf[s.id] >= 3;

            return (
              <div
                key={s.id}
                style={{
                  position: "absolute",
                  left: 8,
                  right: 8,
                  height: ITEM_H - 4,
                  // top drives the swap animation — CSS transition makes it smooth
                  top: visualPos * ITEM_H,
                  transition: "top 0.55s cubic-bezier(.4,0,.2,1), background 0.5s, border-color 0.5s, opacity 0.5s",
                  display: "flex",
                  alignItems: "center",
                  gap: 5,
                  padding: "0 8px",
                  borderRadius: 5,
                  background: isTop ? `rgba(${C[4].rgb},0.1)` : "#111820",
                  border: `1px solid ${isTop ? `rgba(${C[4].rgb},0.4)` : "#21262D"}`,
                  opacity: isDim ? 0.28 : 1,
                  fontFamily: "'JetBrains Mono',monospace",
                  fontSize: 10,
                  boxShadow: isTop ? `0 0 10px rgba(${C[4].rgb},0.12)` : "none",
                  zIndex: isTop ? 2 : 1,
                }}
              >
                {isTop && (
                  <span style={{ width: 20, color: C[4].hex, fontWeight: 700, fontSize: 11, flexShrink: 0 }}>
                    #{sortRankOf[s.id] + 1}
                  </span>
                )}
                <span style={{ flex: 1, color: isTop ? "#E6EDF3" : "#8B949E" }}>{s.label}</span>
                <span style={{ color: "#8B949E", fontSize: 9 }}>{s.cost}</span>
                {isTop && (
                  <div style={{ width: 32, height: 4, borderRadius: 2, background: "#1C2128", overflow: "hidden", flexShrink: 0 }}>
                    <div style={{ width: `${s.score * 100}%`, height: "100%", background: C[4].hex, transition: "width 0.8s ease" }} />
                  </div>
                )}
                <span style={{ color: isTop ? C[4].hex : "#3D444D", minWidth: 30, textAlign: "right", fontWeight: isTop ? 700 : 400, fontSize: 10 }}>
                  {s.score.toFixed(2)}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {expanded && (
        <div style={{ borderRadius: 6, padding: "5px 10px", background: `rgba(${C[4].rgb},0.08)`, border: `1px solid rgba(${C[4].rgb},0.25)`, fontFamily: "'JetBrains Mono',monospace", fontSize: 9, color: C[4].hex, animation: "popIn 0.3s ease", flexShrink: 0 }}>
          top-3 passed to context window ✓
        </div>
      )}
    </div>
  );
}

// ─── Stage 5: Claude chat response (white bg) ─────────────────────────────────

// We render the response as structured blocks that appear progressively
const RESPONSE_BLOCKS = [
  {
    type: "header",
    text: "Here are the top 3 costliest queries from the last 7 days:",
    delay: 0,
    duration: 900,
  },
  {
    type: "query-card",
    rank: 1,
    name: "orders_scan_full_table",
    cost: "$4.20",
    slots: "18,400 slot-ms",
    warning: "Full table scan — no partition filter on orders",
    delay: 1100,
    duration: 600,
  },
  {
    type: "query-card",
    rank: 2,
    name: "events_scan_7d",
    cost: "$2.10",
    slots: "9,200 slot-ms",
    warning: "Missing clustering key on event_type column",
    delay: 1900,
    duration: 600,
  },
  {
    type: "query-card",
    rank: 3,
    name: "users_join_unindexed",
    cost: "$1.80",
    slots: "7,100 slot-ms",
    warning: "Cross-region join (us-east1 → eu-west1)",
    delay: 2700,
    duration: 600,
  },
  {
    type: "recommendation",
    text: "💡 Partition orders by date column — estimated saving ~$3.10/day. Adding clustering on events.event_type could cut events_scan cost by ~60%.",
    delay: 3500,
    duration: 700,
  },
];

function Stage5({ ms }: { ms: number }) {
  const on = inW(ms, 4);
  const localMs = Math.max(0, ms - 19000);
  const [srcOpen, setSrcOpen] = useState(false);
  const showSrc = on && localMs > 4200;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 7, height: "100%" }}>
      {/* model badge */}
      <div style={{ display: "flex", alignItems: "center", gap: 6, flexShrink: 0 }}>
        <div style={{ width: 22, height: 22, borderRadius: "50%", background: `rgba(${C[5].rgb},0.18)`, border: `1.5px solid ${C[5].hex}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 700, color: C[5].hex, flexShrink: 0 }}>C</div>
        <span style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#8B949E" }}>claude-sonnet-4-5 · via Portkey</span>
        {on && (
          <span style={{ marginLeft: "auto", fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: C[5].hex, padding: "1px 6px", borderRadius: 3, background: `rgba(${C[5].rgb},0.12)`, border: `1px solid rgba(${C[5].rgb},0.3)` }}>
            {localMs < 4200 ? "streaming…" : "done ✓"}
          </span>
        )}
      </div>

      {/* WHITE response card */}
      <div style={{ flex: 1, borderRadius: 12, background: "#FFFFFF", border: "1.5px solid #E2E8F0", padding: "12px 14px", overflow: "hidden", minHeight: 0, boxShadow: on ? "0 4px 28px rgba(239,68,68,0.1)" : "0 2px 8px rgba(0,0,0,0.06)", transition: "box-shadow 0.4s", display: "flex", flexDirection: "column", gap: 8 }}>
        {RESPONSE_BLOCKS.map((block, bi) => {
          const blockP = pct(ms, 19000 + block.delay, block.duration);
          if (blockP <= 0) return null;

          if (block.type === "header") {
            const txt = (block as { text: string }).text;
            const chars = Math.floor(blockP * txt.length);
            return (
              <p key={bi} style={{ margin: 0, fontSize: 12, color: "#1E293B", fontWeight: 500, lineHeight: 1.5 }}>
                {txt.slice(0, chars)}
                {blockP < 1 && <span style={{ display: "inline-block", width: 2, height: 13, background: "#64748B", marginLeft: 2, verticalAlign: "middle", animation: "blink 0.65s step-end infinite" }} />}
              </p>
            );
          }

          if (block.type === "query-card") {
            const bc = block as typeof block & { rank: number; name: string; cost: string; slots: string; warning: string };
            return (
              <div key={bi} style={{
                borderRadius: 8, background: "#F8FAFC", border: "1px solid #E2E8F0",
                padding: "9px 11px",
                opacity: blockP, transform: `translateY(${(1 - blockP) * 8}px)`,
                transition: "opacity 0.4s, transform 0.4s",
              }}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 4 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={{ width: 20, height: 20, borderRadius: "50%", background: bc.rank === 1 ? "#FEF3C7" : bc.rank === 2 ? "#FEE2E2" : "#EDE9FE", color: bc.rank === 1 ? "#92400E" : bc.rank === 2 ? "#991B1B" : "#5B21B6", fontSize: 10, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{bc.rank}</span>
                    <code style={{ fontSize: 11, fontFamily: "'JetBrains Mono',monospace", color: "#1E293B", fontWeight: 600, background: "#EEF2FF", padding: "1px 5px", borderRadius: 4 }}>{bc.name}</code>
                  </div>
                  <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                    <span style={{ fontSize: 10, fontFamily: "'JetBrains Mono',monospace", fontWeight: 700, color: "#DC2626", background: "#FEF2F2", padding: "1px 6px", borderRadius: 4 }}>{bc.cost}</span>
                    <span style={{ fontSize: 10, fontFamily: "'JetBrains Mono',monospace", color: "#64748B", background: "#F1F5F9", padding: "1px 6px", borderRadius: 4 }}>{bc.slots}</span>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "flex-start", gap: 5 }}>
                  <span style={{ fontSize: 11, flexShrink: 0, marginTop: 1 }}>⚠️</span>
                  <span style={{ fontSize: 10, color: "#64748B", lineHeight: 1.45 }}>{bc.warning}</span>
                </div>
              </div>
            );
          }

          if (block.type === "recommendation") {
            const rc = block as typeof block & { text: string };
            const chars = Math.floor(blockP * rc.text.length);
            return (
              <div key={bi} style={{
                borderRadius: 8, background: "#ECFDF5", border: "1.5px solid #A7F3D0",
                padding: "9px 11px",
                opacity: blockP, transform: `translateY(${(1 - blockP) * 8}px)`,
                transition: "opacity 0.4s, transform 0.4s",
              }}>
                <span style={{ fontSize: 11, color: "#065F46", lineHeight: 1.5 }}>
                  {rc.text.slice(0, chars)}
                  {blockP < 1 && <span style={{ display: "inline-block", width: 2, height: 12, background: "#10B981", marginLeft: 2, verticalAlign: "middle", animation: "blink 0.65s step-end infinite" }} />}
                </span>
              </div>
            );
          }

          return null;
        })}
      </div>

      {/* sources */}
      {showSrc && (
        <div style={{ borderRadius: 7, overflow: "hidden", border: "1px solid #30363D", animation: "popIn 0.2s ease", flexShrink: 0 }}>
          <button onClick={() => setSrcOpen((o) => !o)} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "5px 10px", background: "#161B22", border: "none", cursor: "pointer", fontFamily: "'JetBrains Mono',monospace", fontSize: 9, color: "#8B949E" }}>
            <span>Sources · 3 chunks · avg similarity 0.88</span>
            <span style={{ transform: srcOpen ? "rotate(180deg)" : "none", transition: "transform 0.2s" }}>▾</span>
          </button>
          {srcOpen && (
            <div style={{ background: "#080D13", padding: "7px 10px", display: "flex", flexDirection: "column", gap: 4 }}>
              {["bq_query_history · orders_scan_2024_01_09 · sim=0.94", "bq_query_history · events_scan_2024_01_08 · sim=0.81", "bq_quota_metrics · slot_summary_7d · sim=0.89"].map((s) => (
                <span key={s} style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#8B949E" }}>→ {s}</span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Bottom example cards ─────────────────────────────────────────────────────
const CARD_DATA = [
  {
    emoji: "💰",
    label: "Queries Cost",
    col: C[2],
    questions: [
      "What are the costliest queries this week?",
      "Who is spending the most on BigQuery?",
      "Show me quota usage for rea-gcp-dp-dev",
    ],
  },
  {
    emoji: "🔍",
    label: "Asset Discovery",
    col: C[1],
    questions: [
      "What columns does the orders table have?",
      "List all tables in the marketing dataset",
      "Are there any deprecated datasets?",
    ],
  },
  {
    emoji: "⚙️",
    label: "Optimisation",
    col: C[4],
    questions: [
      "Which tables are not partitioned?",
      "Which queries could benefit from clustering?",
      "How can I reduce query consumption by 40%?",
    ],
  },
];

function BottomCard({ emoji, label, col, questions, delay }: typeof CARD_DATA[0] & { delay: number }) {
  const [hov, setHov] = useState(false);
  const [activeQ, setActiveQ] = useState<number | null>(null);

  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => { setHov(false); setActiveQ(null); }}
      style={{
        flex: 1,
        borderRadius: 12,
        background: hov ? `rgba(${col.rgb},0.06)` : "#111820",
        border: `1.5px solid ${hov ? col.hex : "#21262D"}`,
        padding: "10px 12px",
        cursor: "pointer",
        transition: "all 0.25s ease",
        boxShadow: hov ? `0 0 24px rgba(${col.rgb},0.18)` : "none",
        transform: hov ? "translateY(-2px)" : "translateY(0)",
        animation: `cardFloat 3.5s ${delay}s ease-in-out infinite`,
        userSelect: "none",
      }}
    >
      {/* header */}
      <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 8 }}>
        <span style={{ fontSize: 18 }}>{emoji}</span>
        <span style={{ fontSize: 12, fontWeight: 700, color: col.hex }}>{label}</span>
        <span style={{ marginLeft: "auto", fontSize: 9, color: hov ? col.hex : "#3D444D", fontFamily: "'JetBrains Mono',monospace", transition: "color 0.2s" }}>click to ask →</span>
      </div>

      {/* questions list */}
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        {questions.map((q, i) => (
          <div
            key={i}
            onMouseEnter={() => setActiveQ(i)}
            onMouseLeave={() => setActiveQ(null)}
            onClick={(e) => e.stopPropagation()}
            style={{
              display: "flex",
              alignItems: "flex-start",
              gap: 6,
              padding: "5px 8px",
              borderRadius: 7,
              background: activeQ === i ? `rgba(${col.rgb},0.12)` : hov ? `rgba(${col.rgb},0.04)` : "transparent",
              border: `1px solid ${activeQ === i ? `rgba(${col.rgb},0.4)` : "transparent"}`,
              transition: "all 0.18s ease",
              cursor: "pointer",
            }}
          >
            <span style={{ color: activeQ === i ? col.hex : "#3D444D", fontSize: 10, marginTop: 1, flexShrink: 0 }}>›</span>
            <span style={{ fontSize: 10, color: activeQ === i ? col.hex : "#8B949E", lineHeight: 1.4, transition: "color 0.18s" }}>{q}</span>
            {activeQ === i && (
              <span style={{ marginLeft: "auto", fontSize: 9, color: col.hex, fontFamily: "'JetBrains Mono',monospace", flexShrink: 0, animation: "popIn 0.15s ease" }}>ask ↗</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Stage meta ───────────────────────────────────────────────────────────────
const STAGE_META = [
  { n: 1 as const, label: "You ask",          sub: "Streamlit chat",   icon: "🗂️" },
  { n: 2 as const, label: "Intent detected",  sub: "NLP router",       icon: "⚡" },
  { n: 3 as const, label: "RAG (ChromaDB)",   sub: "Vector retrieval", icon: "🗄️" },
  { n: 4 as const, label: "Reranker",         sub: "Cross-encoder",    icon: "🔀" },
  { n: 5 as const, label: "Claude answers",   sub: "LLM generation",   icon: "🤖" },
];
const LEGEND = [
  { label: "User",     col: C[1] },
  { label: "Intent",   col: C[2] },
  { label: "Retrieve", col: C[3] },
  { label: "Rerank",   col: C[4] },
  { label: "Answer",   col: C[5] },
];

// ─── responsive width hook ────────────────────────────────────────────────────
function useWindowWidth() {
  const [w, setW] = useState(typeof window !== "undefined" ? window.innerWidth : 1280);
  useEffect(() => {
    const fn = () => setW(window.innerWidth);
    window.addEventListener("resize", fn);
    return () => window.removeEventListener("resize", fn);
  }, []);
  return w;
}

// ─── shared card shell (used by both layouts) ─────────────────────────────────
function StageCard({
  stage, i, on, ms, stageActive, compact,
}: {
  stage: typeof STAGE_META[0];
  i: number;
  on: boolean;
  ms: number;
  stageActive: boolean[];
  compact?: boolean; // mobile collapsed header-only mode
}) {
  const col = C[stage.n];
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        borderRadius: compact ? 10 : 12,
        background: on
          ? `linear-gradient(145deg,rgba(${col.rgb},0.09) 0%,#0D1117 50%)`
          : "#0D1117",
        border: `1.5px solid ${on ? col.hex : "#21262D"}`,
        boxShadow: on
          ? `0 0 0 1px rgba(${col.rgb},0.08),0 6px 32px rgba(${col.rgb},0.2),inset 0 0 50px rgba(${col.rgb},0.04)`
          : "none",
        padding: compact ? "9px 12px" : "10px 12px",
        transition: "all 0.5s cubic-bezier(.4,0,.2,1)",
        opacity: on ? 1 : compact ? 0.55 : 0.5,
        flex: compact ? undefined : 1,
        overflow: "hidden",
      }}
    >
      {/* header row */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span
            style={{
              fontFamily: "'JetBrains Mono',monospace",
              fontSize: 9,
              fontWeight: 700,
              padding: "1px 5px",
              borderRadius: 3,
              background: on ? `rgba(${col.rgb},0.18)` : "#1C2128",
              color: on ? col.hex : "#3D444D",
              border: `1px solid ${on ? `rgba(${col.rgb},0.45)` : "#30363D"}`,
              transition: "all 0.35s",
              flexShrink: 0,
            }}
          >
            {String(stage.n).padStart(2, "0")}
          </span>
          <div>
            <div
              style={{
                fontSize: compact ? 11 : 12,
                fontWeight: 700,
                color: on ? "#E6EDF3" : "#8B949E",
                transition: "color 0.35s",
                letterSpacing: "-0.01em",
                lineHeight: 1.2,
              }}
            >
              {stage.icon} {stage.label}
            </div>
            {!compact && (
              <div style={{ fontSize: 9, color: on ? col.hex : "#3D444D", transition: "color 0.35s" }}>
                {stage.sub}
              </div>
            )}
          </div>
        </div>
        {on && (
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <span style={{ fontSize: 8, fontFamily: "'JetBrains Mono',monospace", color: col.hex, opacity: 0.85 }}>LIVE</span>
            <span
              style={{
                width: 7, height: 7, borderRadius: "50%",
                background: col.hex, boxShadow: `0 0 8px ${col.hex}`,
                animation: "pulse 1s ease-in-out infinite",
                flexShrink: 0,
              }}
            />
          </div>
        )}
      </div>

      {/* content — only when not collapsed */}
      {!compact && (
        <>
          <div style={{ height: 1, background: on ? `rgba(${col.rgb},0.3)` : "#21262D", margin: "8px 0", flexShrink: 0, transition: "background 0.35s" }} />
          <div style={{ flex: 1, minHeight: 0 }}>
            {i === 0 && <Stage1 ms={ms} />}
            {i === 1 && <Stage2 ms={ms} />}
            {i === 2 && <Stage3 ms={ms} />}
            {i === 3 && <Stage4 ms={ms} />}
            {i === 4 && <Stage5 ms={ms} />}
          </div>
        </>
      )}
    </div>
  );
}

// ─── vertical dashed arrow (mobile) ──────────────────────────────────────────
function VertArrow({ col, on }: { col: { hex: string; rgb: string }; on: boolean }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", height: 28, position: "relative", flexShrink: 0 }}>
      <svg width="16" height="28" viewBox="0 0 16 28" style={{ overflow: "visible" }}>
        <defs>
          <marker id={`va-${col.hex.replace("#","")}`} markerWidth="6" markerHeight="6" refX="3" refY="5" orient="auto">
            <path d="M0,0 L3,5 L6,0 Z" fill={on ? col.hex : "#2A3140"} style={{ transition: "fill 0.3s" }} />
          </marker>
        </defs>
        <line
          x1="8" y1="0" x2="8" y2="22"
          stroke={on ? col.hex : "#2A3140"}
          strokeWidth="1.5"
          strokeDasharray="5 3"
          markerEnd={`url(#va-${col.hex.replace("#","")})`}
          style={{ transition: "stroke 0.3s", animation: on ? "dashMoveV 0.5s linear infinite" : "none" }}
        />
      </svg>
      {on && (
        <span
          style={{
            position: "absolute",
            top: 0,
            left: "50%",
            width: 8,
            height: 8,
            borderRadius: "50%",
            background: col.hex,
            transform: "translateX(-50%)",
            boxShadow: `0 0 10px 3px ${col.hex}`,
            animation: "dotTravelV 0.9s ease-in-out infinite",
            pointerEvents: "none",
          }}
        />
      )}
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const ms = useLoopMs();
  const w  = useWindowWidth();
  const activeIdx  = [0, 1, 2, 3, 4].findIndex((i) => inW(ms, i));
  const stageActive = STAGE_META.map((_, i) => inW(ms, i));

  const isMobile = w < 768;

  // ── shared pieces ──────────────────────────────────────────────────────────
  const gridOverlay = (
    <div style={{ position: "fixed", inset: 0, backgroundImage: "linear-gradient(rgba(255,255,255,0.012) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.012) 1px,transparent 1px)", backgroundSize: "40px 40px", pointerEvents: "none", zIndex: 0 }} />
  );

  const progressBar = (
    <div style={{ display: "flex", alignItems: "center", gap: 3, flexShrink: 0, position: "relative", zIndex: 1, marginBottom: isMobile ? 8 : 10 }}>
      {[C[1], C[2], C[3], C[4], C[5]].map((col, i) => {
        const done   = i < activeIdx;
        const active = i === activeIdx;
        return (
          <div
            key={i}
            style={{
              flex: 1, height: isMobile ? 4 : 3, borderRadius: 2,
              background: done ? col.hex : active ? `rgba(${col.rgb},0.55)` : "#21262D",
              boxShadow: active ? `0 0 10px ${col.hex}` : "none",
              transition: "all 0.6s ease",
              animation: active ? "barPulse 1.8s ease-in-out infinite" : "none",
            }}
          />
        );
      })}
    </div>
  );

  const keyframes = (
    <style>{`
      @keyframes dashMove  { to { stroke-dashoffset: -11; } }
      @keyframes dashMoveV { to { stroke-dashoffset: -8; } }
      @keyframes dotTravel {
        0%   { left: 0; opacity: 0; }
        8%   { opacity: 1; }
        92%  { opacity: 1; }
        100% { left: calc(100% - 10px); opacity: 0; }
      }
      @keyframes dotTravelV {
        0%   { top: 0; opacity: 0; }
        8%   { opacity: 1; }
        92%  { opacity: 1; }
        100% { top: 22px; opacity: 0; }
      }
      @keyframes blink { 50% { opacity: 0; } }
      @keyframes popIn {
        from { opacity: 0; transform: scale(0.88); }
        to   { opacity: 1; transform: scale(1); }
      }
      @keyframes bouncePop {
        0%  { transform: scale(0.7); }
        60% { transform: scale(1.18); }
        100%{ transform: scale(1); }
      }
      @keyframes pulse {
        0%,100% { transform: scale(1); opacity: 1; }
        50%      { transform: scale(1.4); opacity: 0.6; }
      }
      @keyframes gentleBob {
        0%,100% { transform: translateY(0); }
        50%      { transform: translateY(-5px); }
      }
      @keyframes jumpDot {
        0%,100% { transform: translateY(0); }
        40%     { transform: translateY(-8px); }
      }
      @keyframes fadeSlideIn {
        from { opacity: 0; transform: translateX(-5px); }
        to   { opacity: 1; transform: translateX(0); }
      }
      @keyframes barPulse {
        0%,100% { opacity: 0.6; }
        50%      { opacity: 1; }
      }
      @keyframes cardFloat {
        0%,100% { transform: translateY(0); }
        50%      { transform: translateY(-3px); }
      }
    `}</style>
  );

  // ── MOBILE layout ──────────────────────────────────────────────────────────
  if (isMobile) {
    return (
      <div style={{ width: "100vw", minHeight: "100vh", background: "#0D1117", fontFamily: "'Inter',ui-sans-serif,sans-serif", display: "flex", flexDirection: "column", padding: "12px 14px 16px", boxSizing: "border-box", overflowY: "auto", overflowX: "hidden" }}>
        {gridOverlay}

        {/* mobile header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8, flexShrink: 0, position: "relative", zIndex: 1 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <h1 style={{ margin: 0, fontSize: 16, fontWeight: 700, letterSpacing: "-0.03em", color: "#E6EDF3" }}>Talk to Your Data</h1>
              <span style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#8B949E", background: "#161B22", border: "1px solid #30363D", padding: "1px 5px", borderRadius: 4 }}>demo</span>
            </div>
            <p style={{ margin: "2px 0 0", fontSize: 9, color: "#8B949E" }}>RAG pipeline · BigQuery · sequential flow</p>
          </div>
          {/* live indicator dot */}
          {activeIdx >= 0 && (
            <span
              style={{
                width: 8, height: 8, borderRadius: "50%",
                background: [C[1],C[2],C[3],C[4],C[5]][activeIdx].hex,
                boxShadow: `0 0 8px ${[C[1],C[2],C[3],C[4],C[5]][activeIdx].hex}`,
                animation: "pulse 1s ease-in-out infinite",
                flexShrink: 0,
              }}
            />
          )}
        </div>

        {progressBar}

        {/* Neo strip */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            padding: "8px 12px",
            borderRadius: 10,
            background: "#111820",
            border: "1px solid #21262D",
            marginBottom: 10,
            flexShrink: 0,
            position: "relative",
            zIndex: 1,
          }}
        >
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: "50%",
              background: activeIdx === 4
                ? "linear-gradient(135deg,#DCFCE7,#BBF7D0)"
                : activeIdx >= 1
                ? "linear-gradient(135deg,#FEF9C3,#FDE68A)"
                : "linear-gradient(135deg,#F1F5F9,#E2E8F0)",
              border: `2px solid ${activeIdx === 4 ? "#22C55E" : activeIdx >= 1 ? "#F59E0B" : "#CBD5E1"}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 22, flexShrink: 0,
              animation: activeIdx === 4 ? "bouncePop 0.55s cubic-bezier(.17,.67,.83,.67)" : activeIdx >= 1 && activeIdx <= 3 ? "gentleBob 2.5s ease-in-out infinite" : "none",
            }}
          >
            {activeIdx === 4 ? "😄" : activeIdx >= 1 ? "🤔" : "😕"}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#E6EDF3" }}>Neo</div>
            <div style={{ fontSize: 10, color: "#8B949E", lineHeight: 1.4 }}>
              {activeIdx === 4
                ? "Finally! Now I know which queries to fix."
                : activeIdx >= 1 && activeIdx <= 3
                ? "Hmm, let me see what the system finds…"
                : '"I have no idea which queries are burning my budget!"'}
            </div>
          </div>
        </div>

        {/* vertical stage list */}
        <div style={{ display: "flex", flexDirection: "column", gap: 0, position: "relative", zIndex: 1 }}>
          {STAGE_META.map((stage, i) => {
            const col = C[stage.n];
            const on  = stageActive[i];
            return (
              <div key={stage.n} style={{ display: "flex", flexDirection: "column" }}>
                {/* vertical arrow from Neo to first stage */}
                {i === 0 && (
                  <VertArrow col={C[1]} on={stageActive[0]} />
                )}

                {/* collapsed header when inactive, expanded card when active */}
                {on ? (
                  // active — full card with content
                  <StageCard stage={stage} i={i} on={on} ms={ms} stageActive={stageActive} />
                ) : (
                  // inactive — compact pill
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      padding: "8px 12px",
                      borderRadius: 10,
                      background: "#0D1117",
                      border: `1px solid #21262D`,
                      opacity: 0.5,
                    }}
                  >
                    <span
                      style={{
                        fontFamily: "'JetBrains Mono',monospace",
                        fontSize: 9,
                        fontWeight: 700,
                        padding: "1px 5px",
                        borderRadius: 3,
                        background: "#1C2128",
                        color: "#3D444D",
                        border: "1px solid #30363D",
                        flexShrink: 0,
                      }}
                    >
                      {String(stage.n).padStart(2, "0")}
                    </span>
                    <span style={{ fontSize: 12 }}>{stage.icon}</span>
                    <span style={{ fontSize: 11, fontWeight: 600, color: "#8B949E" }}>{stage.label}</span>
                    <span style={{ marginLeft: "auto", fontSize: 9, color: "#3D444D", fontFamily: "'JetBrains Mono',monospace" }}>{stage.sub}</span>
                  </div>
                )}

                {/* vertical arrow to next stage */}
                {i < 4 && (
                  <VertArrow col={col} on={on || stageActive[i + 1]} />
                )}
              </div>
            );
          })}
        </div>

        {/* mobile bottom chips — horizontal scroll */}
        <div style={{ marginTop: 12, flexShrink: 0, position: "relative", zIndex: 1 }}>
          <div style={{ fontSize: 10, color: "#8B949E", marginBottom: 6 }}>Try asking:</div>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 4 }}>
            {CARD_DATA.map((card) => (
              <div
                key={card.label}
                style={{
                  flexShrink: 0,
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  padding: "7px 12px",
                  borderRadius: 20,
                  background: "#161B22",
                  border: `1px solid rgba(${card.col.rgb},0.4)`,
                  cursor: "pointer",
                }}
              >
                <span style={{ fontSize: 14 }}>{card.emoji}</span>
                <span style={{ fontSize: 11, fontWeight: 600, color: card.col.hex, whiteSpace: "nowrap" }}>{card.label}</span>
              </div>
            ))}
          </div>
        </div>

        {keyframes}
      </div>
    );
  }

  // ── DESKTOP layout (existing horizontal pipeline) ─────────────────────────
  return (
    <div style={{ width: "100vw", height: "100vh", background: "#0D1117", fontFamily: "'Inter',ui-sans-serif,sans-serif", display: "flex", flexDirection: "column", padding: "14px 18px 12px", overflow: "hidden", boxSizing: "border-box" }}>
      {gridOverlay}

      {/* header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8, flexShrink: 0, position: "relative", zIndex: 1 }}>
        <div>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
            <h1 style={{ margin: 0, fontSize: 18, fontWeight: 700, letterSpacing: "-0.03em", color: "#E6EDF3" }}>Talk to Your Data</h1>
            <span style={{ fontSize: 10, fontFamily: "'JetBrains Mono',monospace", color: "#8B949E", background: "#161B22", border: "1px solid #30363D", padding: "1px 6px", borderRadius: 4 }}>hackday demo</span>
          </div>
          <p style={{ margin: "2px 0 0", fontSize: 10, color: "#8B949E" }}>RAG pipeline · BigQuery intelligence · sequential flow</p>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {LEGEND.map((l, i) => {
              const on = stageActive[i];
              return (
                <div key={l.label} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: on ? l.col.hex : "#8B949E", transition: "color 0.4s" }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: on ? l.col.hex : "#3D444D", boxShadow: on ? `0 0 8px ${l.col.hex}` : "none", transition: "all 0.4s", flexShrink: 0 }} />
                  {l.label}
                </div>
              );
            })}
          </div>
          <div style={{ fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#8B949E", background: "#161B22", border: "1px solid #30363D", padding: "4px 9px", borderRadius: 6, whiteSpace: "nowrap" }}>
            Streamlit + FastAPI · ChromaDB · Claude via Portkey
          </div>
        </div>
      </div>

      {progressBar}

      {/* main row */}
      <div style={{ display: "flex", flex: "1 1 auto", gap: 0, minHeight: 0, position: "relative", zIndex: 1, alignItems: "stretch" }}>
        {/* Neo */}
        <div style={{ display: "flex", alignItems: "center", paddingRight: 8, flexShrink: 0 }}>
          <Neo activeIdx={activeIdx} />
        </div>
        <div style={{ display: "flex", alignItems: "center", paddingRight: 4, flexShrink: 0 }}>
          <Arrow n={1} on={stageActive[0]} />
        </div>

        {STAGE_META.map((stage, i) => {
          const col = C[stage.n];
          const on  = stageActive[i];
          return (
            <div key={stage.n} style={{ display: "flex", alignItems: "stretch", flex: 1 }}>
              <StageCard stage={stage} i={i} on={on} ms={ms} stageActive={stageActive} />
              {i < 4 && (
                <div style={{ display: "flex", alignItems: "center", padding: "0 2px", flexShrink: 0 }}>
                  <Arrow n={stage.n as 1|2|3|4} on={on || stageActive[i + 1]} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* loop hint */}
      <div style={{ height: 14, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, position: "relative", zIndex: 1 }}>
        {ms > 33200 && (
          <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 9, fontFamily: "'JetBrains Mono',monospace", color: "#3D444D", animation: "popIn 0.2s ease" }}>
            <span style={{ color: C[5].hex }}>↩</span> restarting loop <span style={{ color: C[1].hex }}>↪</span>
          </div>
        )}
      </div>

      {/* bottom cards */}
      <div style={{ display: "flex", gap: 10, flexShrink: 0, position: "relative", zIndex: 1 }}>
        {CARD_DATA.map((card, i) => (
          <BottomCard key={card.label} {...card} delay={i * 0.5} />
        ))}
      </div>

      {keyframes}
    </div>
  );
}
